package com.axmed555.visuals;

import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue SHOW_TRAIL;
    public static final ForgeConfigSpec.BooleanValue SHOW_HITBOX;
    public static final ForgeConfigSpec.BooleanValue SHOW_HIT_EFFECTS;
    
    public static final ForgeConfigSpec.IntValue TRAIL_RED;
    public static final ForgeConfigSpec.IntValue TRAIL_GREEN;
    public static final ForgeConfigSpec.IntValue TRAIL_BLUE;
    
    public static final ForgeConfigSpec.IntValue HITBOX_RED;
    public static final ForgeConfigSpec.IntValue HITBOX_GREEN;
    public static final ForgeConfigSpec.IntValue HITBOX_BLUE;
    
    public static final ForgeConfigSpec.IntValue HIT_EFFECT_RED;
    public static final ForgeConfigSpec.IntValue HIT_EFFECT_GREEN;
    public static final ForgeConfigSpec.IntValue HIT_EFFECT_BLUE;
    
    public static final ForgeConfigSpec.EnumValue<HatStyle> HAT_STYLE;
    
    public static final ForgeConfigSpec.ConfigValue<String> BIND_MESSAGE_1;
    public static final ForgeConfigSpec.ConfigValue<String> BIND_MESSAGE_2;
    public static final ForgeConfigSpec.ConfigValue<String> BIND_MESSAGE_3;
    public static final ForgeConfigSpec.ConfigValue<String> BIND_MESSAGE_4;

    static {
        BUILDER.push("Visual Effects");
        
        SHOW_TRAIL = BUILDER.comment("Enable particle trail effect")
            .define("showTrail", true);
        SHOW_HITBOX = BUILDER.comment("Enable enlarged hitbox rendering")
            .define("showHitbox", true);
        SHOW_HIT_EFFECTS = BUILDER.comment("Enable hit effects")
            .define("showHitEffects", true);
        
        BUILDER.push("Trail Color");
        TRAIL_RED = BUILDER.defineInRange("trailRed", 255, 0, 255);
        TRAIL_GREEN = BUILDER.defineInRange("trailGreen", 0, 0, 255);
        TRAIL_BLUE = BUILDER.defineInRange("trailBlue", 0, 0, 255);
        BUILDER.pop();
        
        BUILDER.push("Hitbox Color");
        HITBOX_RED = BUILDER.defineInRange("hitboxRed", 0, 0, 255);
        HITBOX_GREEN = BUILDER.defineInRange("hitboxGreen", 255, 0, 255);
        HITBOX_BLUE = BUILDER.defineInRange("hitboxBlue", 0, 0, 255);
        BUILDER.pop();
        
        BUILDER.push("Hit Effect Color");
        HIT_EFFECT_RED = BUILDER.defineInRange("hitEffectRed", 255, 0, 255);
        HIT_EFFECT_GREEN = BUILDER.defineInRange("hitEffectGreen", 255, 0, 255);
        HIT_EFFECT_BLUE = BUILDER.defineInRange("hitEffectBlue", 0, 0, 255);
        BUILDER.pop();
        
        HAT_STYLE = BUILDER.comment("Cosmetic hat style")
            .defineEnum("hatStyle", HatStyle.CROWN);
        
        BUILDER.push("Keybind Messages");
        BIND_MESSAGE_1 = BUILDER.comment("Message for bind slot 1")
            .define("bindMessage1", "");
        BIND_MESSAGE_2 = BUILDER.comment("Message for bind slot 2")
            .define("bindMessage2", "");
        BIND_MESSAGE_3 = BUILDER.comment("Message for bind slot 3")
            .define("bindMessage3", "");
        BIND_MESSAGE_4 = BUILDER.comment("Message for bind slot 4")
            .define("bindMessage4", "");
        BUILDER.pop();
        
        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    public enum HatStyle {
        NONE,
        CROWN,
        AURA,
        WINGS,
        HALO
    }
}
