package com.axmed555.visuals.gui;

import com.axmed555.visuals.Config;
import com.axmed555.visuals.KeyInputHandler;
import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.fml.client.gui.widget.Slider;

public class ConfigScreen extends Screen {
    private final Screen parentScreen;
    private int yOffset = 30;
    
    private TextFieldWidget bind1Field;
    private TextFieldWidget bind2Field;
    private TextFieldWidget bind3Field;
    private TextFieldWidget bind4Field;

    public ConfigScreen(Screen parentScreen) {
        super(new StringTextComponent("Axmed555 Visuals Config"));
        this.parentScreen = parentScreen;
    }

    @Override
    protected void init() {
        int leftX = this.width / 2 - 150;
        int rightX = this.width / 2 + 10;
        yOffset = 30;

        addButton(new Button(leftX, yOffset, 140, 20,
            new StringTextComponent("Trail: " + (Config.SHOW_TRAIL.get() ? "ON" : "OFF")),
            (btn) -> {
                Config.SHOW_TRAIL.set(!Config.SHOW_TRAIL.get());
                btn.setMessage(new StringTextComponent("Trail: " + (Config.SHOW_TRAIL.get() ? "ON" : "OFF")));
            }));

        addButton(new Button(rightX, yOffset, 140, 20,
            new StringTextComponent("Hitbox: " + (Config.SHOW_HITBOX.get() ? "ON" : "OFF")),
            (btn) -> {
                Config.SHOW_HITBOX.set(!Config.SHOW_HITBOX.get());
                btn.setMessage(new StringTextComponent("Hitbox: " + (Config.SHOW_HITBOX.get() ? "ON" : "OFF")));
            }));

        yOffset += 25;

        addButton(new Button(leftX, yOffset, 140, 20,
            new StringTextComponent("Hit Effects: " + (Config.SHOW_HIT_EFFECTS.get() ? "ON" : "OFF")),
            (btn) -> {
                Config.SHOW_HIT_EFFECTS.set(!Config.SHOW_HIT_EFFECTS.get());
                btn.setMessage(new StringTextComponent("Hit Effects: " + (Config.SHOW_HIT_EFFECTS.get() ? "ON" : "OFF")));
            }));

        yOffset += 30;

        addSlider("Trail Red", Config.TRAIL_RED.get(), 0, 255, leftX, (val) -> {
            Config.TRAIL_RED.set(val);
        });

        addSlider("Trail Green", Config.TRAIL_GREEN.get(), 0, 255, leftX, (val) -> {
            Config.TRAIL_GREEN.set(val);
        });

        addSlider("Trail Blue", Config.TRAIL_BLUE.get(), 0, 255, leftX, (val) -> {
            Config.TRAIL_BLUE.set(val);
        });

        yOffset = 85;

        addSlider("Hitbox Red", Config.HITBOX_RED.get(), 0, 255, rightX, (val) -> {
            Config.HITBOX_RED.set(val);
        });

        addSlider("Hitbox Green", Config.HITBOX_GREEN.get(), 0, 255, rightX, (val) -> {
            Config.HITBOX_GREEN.set(val);
        });

        addSlider("Hitbox Blue", Config.HITBOX_BLUE.get(), 0, 255, rightX, (val) -> {
            Config.HITBOX_BLUE.set(val);
        });

        yOffset += 30;

        addSlider("Hit R", Config.HIT_EFFECT_RED.get(), 0, 255, leftX, (val) -> {
            Config.HIT_EFFECT_RED.set(val);
        });

        addSlider("Hit G", Config.HIT_EFFECT_GREEN.get(), 0, 255, rightX, (val) -> {
            Config.HIT_EFFECT_GREEN.set(val);
        });

        yOffset += 25;

        addSlider("Hit B", Config.HIT_EFFECT_BLUE.get(), 0, 255, leftX, (val) -> {
            Config.HIT_EFFECT_BLUE.set(val);
        });

        yOffset += 35;
        
        int labelX = leftX;
        int fieldWidth = 300;
        
        drawString(new MatrixStack(), this.font, "Message Binds (NumPad 1-4):", labelX, yOffset, 0xFFFFFF);
        yOffset += 15;
        
        bind1Field = new TextFieldWidget(this.font, labelX, yOffset, fieldWidth, 20, 
            new StringTextComponent("Bind 1"));
        bind1Field.setMaxLength(256);
        bind1Field.setValue(Config.BIND_MESSAGE_1.get());
        bind1Field.setResponder((text) -> Config.BIND_MESSAGE_1.set(text));
        this.children.add(bind1Field);
        addButton(bind1Field);
        yOffset += 25;
        
        bind2Field = new TextFieldWidget(this.font, labelX, yOffset, fieldWidth, 20,
            new StringTextComponent("Bind 2"));
        bind2Field.setMaxLength(256);
        bind2Field.setValue(Config.BIND_MESSAGE_2.get());
        bind2Field.setResponder((text) -> Config.BIND_MESSAGE_2.set(text));
        this.children.add(bind2Field);
        addButton(bind2Field);
        yOffset += 25;
        
        bind3Field = new TextFieldWidget(this.font, labelX, yOffset, fieldWidth, 20,
            new StringTextComponent("Bind 3"));
        bind3Field.setMaxLength(256);
        bind3Field.setValue(Config.BIND_MESSAGE_3.get());
        bind3Field.setResponder((text) -> Config.BIND_MESSAGE_3.set(text));
        this.children.add(bind3Field);
        addButton(bind3Field);
        yOffset += 25;
        
        bind4Field = new TextFieldWidget(this.font, labelX, yOffset, fieldWidth, 20,
            new StringTextComponent("Bind 4"));
        bind4Field.setMaxLength(256);
        bind4Field.setValue(Config.BIND_MESSAGE_4.get());
        bind4Field.setResponder((text) -> Config.BIND_MESSAGE_4.set(text));
        this.children.add(bind4Field);
        addButton(bind4Field);
        yOffset += 30;

        int hatBtnWidth = 90;
        int hatY = yOffset;
        Config.HatStyle currentHat = Config.HAT_STYLE.get();

        for (Config.HatStyle style : Config.HatStyle.values()) {
            int hatX = leftX + (style.ordinal() % 3) * (hatBtnWidth + 5);
            if (style.ordinal() % 3 == 0 && style.ordinal() > 0) {
                hatY += 25;
            }

            addButton(new Button(hatX, hatY, hatBtnWidth, 20,
                new StringTextComponent(style.name() + (currentHat == style ? " ✓" : "")),
                (btn) -> {
                    Config.HAT_STYLE.set(style);
                    this.init(this.minecraft, this.width, this.height);
                }));
        }

        addButton(new Button(this.width / 2 - 100, this.height - 27, 200, 20,
            new StringTextComponent("Done"),
            (btn) -> this.minecraft.setScreen(this.parentScreen)));
    }

    private void addSlider(String label, int value, int min, int max, int x, java.util.function.Consumer<Integer> onChange) {
        addButton(new Slider(x, yOffset, 140, 20, 
            new StringTextComponent(label + ": " + value), 
            new StringTextComponent(""), 
            min, max, value, false, true, (slider) -> {
                onChange.accept((int)slider.getValue());
            }) {
            @Override
            public void updateMessage() {
                this.setMessage(new StringTextComponent(label + ": " + (int)this.getValue()));
            }
        });
        yOffset += 25;
    }

    private void addDoubleSlider(String label, double value, double min, double max, int x, java.util.function.Consumer<Double> onChange) {
        addButton(new Slider(x, yOffset, 140, 20, 
            new StringTextComponent(label + ": " + String.format("%.1f", value)), 
            new StringTextComponent(""), 
            min, max, value, false, true, (slider) -> {
                onChange.accept(slider.getValue());
            }) {
            @Override
            public void updateMessage() {
                this.setMessage(new StringTextComponent(label + ": " + String.format("%.1f", this.getValue())));
            }
        });
        yOffset += 25;
    }

    @Override
    public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(matrixStack);
        drawCenteredString(matrixStack, this.font, this.title.getString(), this.width / 2, 10, 0xFFFFFF);
        
        if (bind1Field != null) bind1Field.render(matrixStack, mouseX, mouseY, partialTicks);
        if (bind2Field != null) bind2Field.render(matrixStack, mouseX, mouseY, partialTicks);
        if (bind3Field != null) bind3Field.render(matrixStack, mouseX, mouseY, partialTicks);
        if (bind4Field != null) bind4Field.render(matrixStack, mouseX, mouseY, partialTicks);
        
        int infoY = this.height - 50;
        drawCenteredString(matrixStack, this.font, 
            "Open GUI: " + KeyInputHandler.openGuiKey.saveString(), 
            this.width / 2, infoY, 0xAAAAAA);
        drawCenteredString(matrixStack, this.font, 
            "Binds: NumPad 1-4", 
            this.width / 2, infoY + 12, 0xAAAAAA);
        
        super.render(matrixStack, mouseX, mouseY, partialTicks);
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (bind1Field != null && bind1Field.mouseClicked(mouseX, mouseY, button)) return true;
        if (bind2Field != null && bind2Field.mouseClicked(mouseX, mouseY, button)) return true;
        if (bind3Field != null && bind3Field.mouseClicked(mouseX, mouseY, button)) return true;
        if (bind4Field != null && bind4Field.mouseClicked(mouseX, mouseY, button)) return true;
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bind1Field != null && bind1Field.keyPressed(keyCode, scanCode, modifiers)) return true;
        if (bind2Field != null && bind2Field.keyPressed(keyCode, scanCode, modifiers)) return true;
        if (bind3Field != null && bind3Field.keyPressed(keyCode, scanCode, modifiers)) return true;
        if (bind4Field != null && bind4Field.keyPressed(keyCode, scanCode, modifiers)) return true;
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    
    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (bind1Field != null && bind1Field.charTyped(codePoint, modifiers)) return true;
        if (bind2Field != null && bind2Field.charTyped(codePoint, modifiers)) return true;
        if (bind3Field != null && bind3Field.charTyped(codePoint, modifiers)) return true;
        if (bind4Field != null && bind4Field.charTyped(codePoint, modifiers)) return true;
        return super.charTyped(codePoint, modifiers);
    }

    @Override
    public void removed() {
        com.axmed555.visuals.AxmedVisuals.saveConfig();
        super.removed();
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(this.parentScreen);
    }
}
