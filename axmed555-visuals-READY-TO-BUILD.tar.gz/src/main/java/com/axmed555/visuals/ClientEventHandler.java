package com.axmed555.visuals;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.IRenderTypeBuffer;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.awt.*;

public class ClientEventHandler {
    private final Minecraft mc = Minecraft.getInstance();

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        if (!Config.SHOW_TRAIL.get() && !Config.SHOW_HITBOX.get()) return;
        
        PlayerEntity player = mc.player;
        if (player == null) return;

        MatrixStack matrixStack = event.getMatrixStack();
        IRenderTypeBuffer.Impl buffer = mc.renderBuffers().bufferSource();
        ActiveRenderInfo camera = mc.gameRenderer.getMainCamera();
        Vector3d cameraPos = camera.getPosition();

        if (Config.SHOW_TRAIL.get()) {
            spawnTrailParticles(player);
        }

        if (Config.SHOW_HITBOX.get()) {
            renderEnlargedHitbox(player, matrixStack, buffer, cameraPos, event.getPartialTicks());
        }

        if (Config.HAT_STYLE.get() != Config.HatStyle.NONE) {
            renderHat(player, matrixStack, cameraPos, event.getPartialTicks());
        }
    }

    private void spawnTrailParticles(PlayerEntity player) {
        if (player.level.random.nextFloat() < 0.3f) {
            float r = Config.TRAIL_RED.get() / 255f;
            float g = Config.TRAIL_GREEN.get() / 255f;
            float b = Config.TRAIL_BLUE.get() / 255f;
            
            double x = player.getX() + (player.level.random.nextDouble() - 0.5) * 0.5;
            double y = player.getY() + player.level.random.nextDouble() * player.getBbHeight();
            double z = player.getZ() + (player.level.random.nextDouble() - 0.5) * 0.5;
            
            player.level.addParticle(new net.minecraft.particles.RedstoneParticleData(r, g, b, 1.0F), 
                x, y, z, 0, 0, 0);
        }
    }

    private void renderEnlargedHitbox(PlayerEntity player, MatrixStack matrixStack, 
                                     IRenderTypeBuffer.Impl buffer, Vector3d cameraPos, 
                                     float partialTicks) {
        AxisAlignedBB box = player.getBoundingBox();
        double multiplier = 1.5;
        
        double centerX = (box.minX + box.maxX) / 2;
        double centerY = (box.minY + box.maxY) / 2;
        double centerZ = (box.minZ + box.maxZ) / 2;
        
        double width = (box.maxX - box.minX) * multiplier / 2;
        double height = (box.maxY - box.minY) * multiplier / 2;
        double depth = (box.maxZ - box.minZ) * multiplier / 2;
        
        AxisAlignedBB enlargedBox = new AxisAlignedBB(
            centerX - width, centerY - height, centerZ - depth,
            centerX + width, centerY + height, centerZ + depth
        );

        matrixStack.pushPose();
        matrixStack.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);
        
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.lineWidth(2.0f);

        float r = Config.HITBOX_RED.get() / 255f;
        float g = Config.HITBOX_GREEN.get() / 255f;
        float b = Config.HITBOX_BLUE.get() / 255f;
        
        WorldRenderer.renderLineBox(matrixStack, buffer.getBuffer(
            net.minecraft.client.renderer.RenderType.LINES), 
            enlargedBox, r, g, b, 1.0f);

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        
        matrixStack.popPose();
        buffer.endBatch();
    }

    private void renderHat(PlayerEntity player, MatrixStack matrixStack, 
                          Vector3d cameraPos, float partialTicks) {
        Config.HatStyle style = Config.HAT_STYLE.get();
        
        matrixStack.pushPose();
        matrixStack.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);
        
        double x = player.getX();
        double y = player.getY() + player.getBbHeight() + 0.5;
        double z = player.getZ();
        
        switch (style) {
            case CROWN:
                renderCrown(x, y, z);
                break;
            case AURA:
                renderAura(x, y - 0.5, z);
                break;
            case WINGS:
                renderWings(x, y - 0.3, z);
                break;
            case HALO:
                renderHalo(x, y, z);
                break;
        }
        
        matrixStack.popPose();
    }

    private void renderCrown(double x, double y, double z) {
        if (mc.player.level.random.nextFloat() < 0.1f) {
            mc.player.level.addParticle(ParticleTypes.END_ROD, 
                x + (mc.player.level.random.nextDouble() - 0.5) * 0.3, 
                y, 
                z + (mc.player.level.random.nextDouble() - 0.5) * 0.3, 
                0, 0.05, 0);
        }
    }

    private void renderAura(double x, double y, double z) {
        if (mc.player.level.random.nextFloat() < 0.2f) {
            double angle = mc.player.level.random.nextDouble() * Math.PI * 2;
            double radius = 0.5;
            mc.player.level.addParticle(ParticleTypes.ENCHANT, 
                x + Math.cos(angle) * radius, 
                y + mc.player.level.random.nextDouble() * 2, 
                z + Math.sin(angle) * radius, 
                0, 0.1, 0);
        }
    }

    private void renderWings(double x, double y, double z) {
        if (mc.player.level.random.nextFloat() < 0.15f) {
            double offsetX = (mc.player.level.random.nextDouble() - 0.5) * 1.0;
            mc.player.level.addParticle(ParticleTypes.FIREWORK, 
                x + offsetX, 
                y, 
                z, 
                0, -0.05, 0);
        }
    }

    private void renderHalo(double x, double y, double z) {
        if (mc.player.level.random.nextFloat() < 0.15f) {
            double angle = mc.player.level.random.nextDouble() * Math.PI * 2;
            double radius = 0.4;
            mc.player.level.addParticle(ParticleTypes.SOUL, 
                x + Math.cos(angle) * radius, 
                y, 
                z + Math.sin(angle) * radius, 
                0, 0, 0);
        }
    }

    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        if (!Config.SHOW_HIT_EFFECTS.get()) return;
        
        Entity entity = event.getEntity();
        if (entity instanceof LivingEntity) {
            spawnHitEffects((LivingEntity) entity);
        }
    }

    private void spawnHitEffects(LivingEntity entity) {
        float r = Config.HIT_EFFECT_RED.get() / 255f;
        float g = Config.HIT_EFFECT_GREEN.get() / 255f;
        float b = Config.HIT_EFFECT_BLUE.get() / 255f;
        
        for (int i = 0; i < 10; i++) {
            double x = entity.getX() + (entity.level.random.nextDouble() - 0.5) * entity.getBbWidth();
            double y = entity.getY() + entity.level.random.nextDouble() * entity.getBbHeight();
            double z = entity.getZ() + (entity.level.random.nextDouble() - 0.5) * entity.getBbWidth();
            
            double vx = (entity.level.random.nextDouble() - 0.5) * 0.2;
            double vy = entity.level.random.nextDouble() * 0.2;
            double vz = (entity.level.random.nextDouble() - 0.5) * 0.2;
            
            entity.level.addParticle(new net.minecraft.particles.RedstoneParticleData(r, g, b, 1.0F), 
                x, y, z, vx, vy, vz);
        }
    }
}
