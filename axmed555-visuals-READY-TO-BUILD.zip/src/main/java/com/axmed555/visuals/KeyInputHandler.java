package com.axmed555.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.util.InputMappings;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.client.settings.KeyModifier;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.glfw.GLFW;

public class KeyInputHandler {
    private static final String CATEGORY = "key.categories.axmed555_visuals";

    public static KeyBinding openGuiKey;
    public static KeyBinding bind1Key;
    public static KeyBinding bind2Key;
    public static KeyBinding bind3Key;
    public static KeyBinding bind4Key;

    public static void register() {
        openGuiKey = new KeyBinding(
            "key.axmed555_visuals.open_gui",
            KeyConflictContext.IN_GAME,
            InputMappings.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            CATEGORY
        );

        bind1Key = new KeyBinding(
            "key.axmed555_visuals.bind1",
            KeyConflictContext.IN_GAME,
            InputMappings.Type.KEYSYM,
            GLFW.GLFW_KEY_KP_1,
            CATEGORY
        );

        bind2Key = new KeyBinding(
            "key.axmed555_visuals.bind2",
            KeyConflictContext.IN_GAME,
            InputMappings.Type.KEYSYM,
            GLFW.GLFW_KEY_KP_2,
            CATEGORY
        );

        bind3Key = new KeyBinding(
            "key.axmed555_visuals.bind3",
            KeyConflictContext.IN_GAME,
            InputMappings.Type.KEYSYM,
            GLFW.GLFW_KEY_KP_3,
            CATEGORY
        );

        bind4Key = new KeyBinding(
            "key.axmed555_visuals.bind4",
            KeyConflictContext.IN_GAME,
            InputMappings.Type.KEYSYM,
            GLFW.GLFW_KEY_KP_4,
            CATEGORY
        );

        ClientRegistry.registerKeyBinding(openGuiKey);
        ClientRegistry.registerKeyBinding(bind1Key);
        ClientRegistry.registerKeyBinding(bind2Key);
        ClientRegistry.registerKeyBinding(bind3Key);
        ClientRegistry.registerKeyBinding(bind4Key);
    }

    @SubscribeEvent
    public static void onKeyInput(InputEvent.KeyInputEvent event) {
        Minecraft mc = Minecraft.getInstance();
        
        if (mc.player == null) return;

        if (openGuiKey.consumeClick()) {
            mc.setScreen(new com.axmed555.visuals.gui.ConfigScreen(mc.screen));
        }

        if (bind1Key.consumeClick()) {
            sendBindMessage(Config.BIND_MESSAGE_1.get());
        }

        if (bind2Key.consumeClick()) {
            sendBindMessage(Config.BIND_MESSAGE_2.get());
        }

        if (bind3Key.consumeClick()) {
            sendBindMessage(Config.BIND_MESSAGE_3.get());
        }

        if (bind4Key.consumeClick()) {
            sendBindMessage(Config.BIND_MESSAGE_4.get());
        }
    }

    private static void sendBindMessage(String message) {
        if (message == null || message.trim().isEmpty()) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.getConnection() != null) {
            mc.player.sendChatMessage(message);
        }
    }
}
