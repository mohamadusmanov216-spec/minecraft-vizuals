package com.axmed555.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.joml.Vector3f;

public class ClientEventHandler {
    private final Minecraft mc = Minecraft.getInstance();

    @SubscribeEvent
    public void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (!Config.SHOW_TRAIL.get() && !Config.SHOW_HITBOX.get()) return;
        
        Player player = mc.player;
        if (player == null) return;

        PoseStack poseStack = event.getPoseStack();
        Vec3 cameraPos = event.getCamera().getPosition();

        if (Config.SHOW_TRAIL.get()) {
            spawnTrailParticles(player);
        }

        if (Config.SHOW_HITBOX.get()) {
            renderEnlargedHitbox(player, poseStack, cameraPos, event.getPartialTick());
        }

        if (Config.HAT_STYLE.get() != Config.HatStyle.NONE) {
            renderHat(player, poseStack, cameraPos, event.getPartialTick());
        }
    }

    private void spawnTrailParticles(Player player) {
        if (player.level().random.nextFloat() < 0.3f) {
            float r = Config.TRAIL_RED.get() / 255f;
            float g = Config.TRAIL_GREEN.get() / 255f;
            float b = Config.TRAIL_BLUE.get() / 255f;
            
            double x = player.getX() + (player.level().random.nextDouble() - 0.5) * 0.5;
            double y = player.getY() + player.level().random.nextDouble() * player.getBbHeight();
            double z = player.getZ() + (player.level().random.nextDouble() - 0.5) * 0.5;
            
            player.level().addParticle(new DustParticleOptions(new Vector3f(r, g, b), 1.0F), 
                x, y, z, 0, 0, 0);
        }
    }

    private void renderEnlargedHitbox(Player player, PoseStack poseStack, 
                                     Vec3 cameraPos, float partialTicks) {
        AABB box = player.getBoundingBox();
        double multiplier = 1.5;
        
        double centerX = (box.minX + box.maxX) / 2;
        double centerY = (box.minY + box.maxY) / 2;
        double centerZ = (box.minZ + box.maxZ) / 2;
        
        double width = (box.maxX - box.minX) * multiplier / 2;
        double height = (box.maxY - box.minY) * multiplier / 2;
        double depth = (box.maxZ - box.minZ) * multiplier / 2;
        
        AABB enlargedBox = new AABB(
            centerX - width, centerY - height, centerZ - depth,
            centerX + width, centerY + height, centerZ + depth
        );

        poseStack.pushPose();
        poseStack.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);
        
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.lineWidth(2.0f);

        float r = Config.HITBOX_RED.get() / 255f;
        float g = Config.HITBOX_GREEN.get() / 255f;
        float b = Config.HITBOX_BLUE.get() / 255f;
        
        MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();
        LevelRenderer.renderLineBox(poseStack, bufferSource.getBuffer(
            net.minecraft.client.renderer.RenderType.lines()), 
            enlargedBox, r, g, b, 1.0f);

        bufferSource.endBatch();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        
        poseStack.popPose();
    }

    private void renderHat(Player player, PoseStack poseStack, 
                          Vec3 cameraPos, float partialTicks) {
        Config.HatStyle style = Config.HAT_STYLE.get();
        
        poseStack.pushPose();
        poseStack.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);
        
        double x = player.getX();
        double y = player.getY() + player.getBbHeight() + 0.5;
        double z = player.getZ();
        
        switch (style) {
            case CROWN:
                renderCrown(x, y, z);
                break;
            case AURA:
                renderAura(x, y - 0.5, z);
                break;
            case WINGS:
                renderWings(x, y - 0.3, z);
                break;
            case HALO:
                renderHalo(x, y, z);
                break;
        }
        
        poseStack.popPose();
    }

    private void renderCrown(double x, double y, double z) {
        if (mc.player.level().random.nextFloat() < 0.2f) {
            float gradient = mc.player.level().random.nextFloat();
            float r = lerp(Config.CROWN_R1.get() / 255f, Config.CROWN_R2.get() / 255f, gradient);
            float g = lerp(Config.CROWN_G1.get() / 255f, Config.CROWN_G2.get() / 255f, gradient);
            float b = lerp(Config.CROWN_B1.get() / 255f, Config.CROWN_B2.get() / 255f, gradient);
            
            double px = x + (mc.player.level().random.nextDouble() - 0.5) * 0.4;
            double py = y;
            double pz = z + (mc.player.level().random.nextDouble() - 0.5) * 0.4;
            
            mc.player.level().addParticle(new DustParticleOptions(new Vector3f(r, g, b), 1.5F), 
                px, py, pz, 0, 0.05, 0);
        }
    }

    private void renderAura(double x, double y, double z) {
        if (mc.player.level().random.nextFloat() < 0.3f) {
            double angle = mc.player.level().random.nextDouble() * Math.PI * 2;
            double radius = 0.6;
            double heightOffset = mc.player.level().random.nextDouble() * 2;
            
            float gradient = (float)(heightOffset / 2.0);
            float r = lerp(Config.AURA_R1.get() / 255f, Config.AURA_R2.get() / 255f, gradient);
            float g = lerp(Config.AURA_G1.get() / 255f, Config.AURA_G2.get() / 255f, gradient);
            float b = lerp(Config.AURA_B1.get() / 255f, Config.AURA_B2.get() / 255f, gradient);
            
            mc.player.level().addParticle(new DustParticleOptions(new Vector3f(r, g, b), 1.0F), 
                x + Math.cos(angle) * radius, 
                y + heightOffset, 
                z + Math.sin(angle) * radius, 
                0, 0.1, 0);
        }
    }

    private void renderWings(double x, double y, double z) {
        if (mc.player.level().random.nextFloat() < 0.25f) {
            double offsetX = (mc.player.level().random.nextDouble() - 0.5) * 1.2;
            float side = offsetX > 0 ? 1.0f : 0.0f;
            
            float r = lerp(Config.WINGS_R1.get() / 255f, Config.WINGS_R2.get() / 255f, side);
            float g = lerp(Config.WINGS_G1.get() / 255f, Config.WINGS_G2.get() / 255f, side);
            float b = lerp(Config.WINGS_B1.get() / 255f, Config.WINGS_B2.get() / 255f, side);
            
            mc.player.level().addParticle(new DustParticleOptions(new Vector3f(r, g, b), 1.2F), 
                x + offsetX, 
                y, 
                z, 
                0, -0.05, 0);
        }
    }

    private void renderHalo(double x, double y, double z) {
        if (mc.player.level().random.nextFloat() < 0.3f) {
            double angle = mc.player.level().random.nextDouble() * Math.PI * 2;
            double radius = 0.5;
            
            float gradient = (float)(angle / (Math.PI * 2));
            float r = lerp(Config.HALO_R1.get() / 255f, Config.HALO_R2.get() / 255f, gradient);
            float g = lerp(Config.HALO_G1.get() / 255f, Config.HALO_G2.get() / 255f, gradient);
            float b = lerp(Config.HALO_B1.get() / 255f, Config.HALO_B2.get() / 255f, gradient);
            
            mc.player.level().addParticle(new DustParticleOptions(new Vector3f(r, g, b), 1.3F), 
                x + Math.cos(angle) * radius, 
                y, 
                z + Math.sin(angle) * radius, 
                0, 0, 0);
        }
    }
    
    private float lerp(float start, float end, float t) {
        return start + (end - start) * t;
    }

    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        if (!Config.SHOW_HIT_EFFECTS.get()) return;
        
        Entity entity = event.getEntity();
        if (entity instanceof LivingEntity) {
            spawnHitEffects((LivingEntity) entity);
        }
    }

    private void spawnHitEffects(LivingEntity entity) {
        float r = Config.HIT_EFFECT_RED.get() / 255f;
        float g = Config.HIT_EFFECT_GREEN.get() / 255f;
        float b = Config.HIT_EFFECT_BLUE.get() / 255f;
        
        for (int i = 0; i < 10; i++) {
            double x = entity.getX() + (entity.level().random.nextDouble() - 0.5) * entity.getBbWidth();
            double y = entity.getY() + entity.level().random.nextDouble() * entity.getBbHeight();
            double z = entity.getZ() + (entity.level().random.nextDouble() - 0.5) * entity.getBbWidth();
            
            double vx = (entity.level().random.nextDouble() - 0.5) * 0.2;
            double vy = entity.level().random.nextDouble() * 0.2;
            double vz = (entity.level().random.nextDouble() - 0.5) * 0.2;
            
            entity.level().addParticle(new DustParticleOptions(new Vector3f(r, g, b), 1.0F), 
                x, y, z, vx, vy, vz);
        }
    }
}
