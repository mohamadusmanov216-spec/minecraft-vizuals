package com.axmed555.visuals.gui;

import com.axmed555.visuals.Config;
import com.axmed555.visuals.KeyInputHandler;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.widget.ForgeSlider;

public class ConfigScreen extends Screen {
    private final Screen parentScreen;
    private int yOffset = 30;
    
    private EditBox bind1Field;
    private EditBox bind2Field;
    private EditBox bind3Field;
    private EditBox bind4Field;

    public ConfigScreen(Screen parentScreen) {
        super(Component.literal("Axmed555 Visuals Config"));
        this.parentScreen = parentScreen;
    }

    @Override
    protected void init() {
        int leftX = this.width / 2 - 150;
        int rightX = this.width / 2 + 10;
        yOffset = 30;

        addRenderableWidget(Button.builder(
            Component.literal("Trail: " + (Config.SHOW_TRAIL.get() ? "ON" : "OFF")),
            (btn) -> {
                Config.SHOW_TRAIL.set(!Config.SHOW_TRAIL.get());
                btn.setMessage(Component.literal("Trail: " + (Config.SHOW_TRAIL.get() ? "ON" : "OFF")));
            })
            .bounds(leftX, yOffset, 140, 20)
            .build());

        addRenderableWidget(Button.builder(
            Component.literal("Hitbox: " + (Config.SHOW_HITBOX.get() ? "ON" : "OFF")),
            (btn) -> {
                Config.SHOW_HITBOX.set(!Config.SHOW_HITBOX.get());
                btn.setMessage(Component.literal("Hitbox: " + (Config.SHOW_HITBOX.get() ? "ON" : "OFF")));
            })
            .bounds(rightX, yOffset, 140, 20)
            .build());

        yOffset += 25;

        addRenderableWidget(Button.builder(
            Component.literal("Hit Effects: " + (Config.SHOW_HIT_EFFECTS.get() ? "ON" : "OFF")),
            (btn) -> {
                Config.SHOW_HIT_EFFECTS.set(!Config.SHOW_HIT_EFFECTS.get());
                btn.setMessage(Component.literal("Hit Effects: " + (Config.SHOW_HIT_EFFECTS.get() ? "ON" : "OFF")));
            })
            .bounds(leftX, yOffset, 140, 20)
            .build());

        yOffset += 30;

        addSlider("Trail Red", Config.TRAIL_RED.get(), 0, 255, leftX, (val) -> {
            Config.TRAIL_RED.set(val);
        });

        addSlider("Trail Green", Config.TRAIL_GREEN.get(), 0, 255, leftX, (val) -> {
            Config.TRAIL_GREEN.set(val);
        });

        addSlider("Trail Blue", Config.TRAIL_BLUE.get(), 0, 255, leftX, (val) -> {
            Config.TRAIL_BLUE.set(val);
        });

        yOffset = 85;

        addSlider("Hitbox Red", Config.HITBOX_RED.get(), 0, 255, rightX, (val) -> {
            Config.HITBOX_RED.set(val);
        });

        addSlider("Hitbox Green", Config.HITBOX_GREEN.get(), 0, 255, rightX, (val) -> {
            Config.HITBOX_GREEN.set(val);
        });

        addSlider("Hitbox Blue", Config.HITBOX_BLUE.get(), 0, 255, rightX, (val) -> {
            Config.HITBOX_BLUE.set(val);
        });

        yOffset += 30;

        addSlider("Hit R", Config.HIT_EFFECT_RED.get(), 0, 255, leftX, (val) -> {
            Config.HIT_EFFECT_RED.set(val);
        });

        addSlider("Hit G", Config.HIT_EFFECT_GREEN.get(), 0, 255, rightX, (val) -> {
            Config.HIT_EFFECT_GREEN.set(val);
        });

        yOffset += 25;

        addSlider("Hit B", Config.HIT_EFFECT_BLUE.get(), 0, 255, leftX, (val) -> {
            Config.HIT_EFFECT_BLUE.set(val);
        });

        yOffset += 35;
        
        int labelX = leftX;
        int fieldWidth = 300;
        
        yOffset += 15;
        
        bind1Field = new EditBox(this.font, labelX, yOffset, fieldWidth, 20, 
            Component.literal("Bind 1"));
        bind1Field.setMaxLength(256);
        bind1Field.setValue(Config.BIND_MESSAGE_1.get());
        bind1Field.setResponder((text) -> Config.BIND_MESSAGE_1.set(text));
        addRenderableWidget(bind1Field);
        yOffset += 25;
        
        bind2Field = new EditBox(this.font, labelX, yOffset, fieldWidth, 20,
            Component.literal("Bind 2"));
        bind2Field.setMaxLength(256);
        bind2Field.setValue(Config.BIND_MESSAGE_2.get());
        bind2Field.setResponder((text) -> Config.BIND_MESSAGE_2.set(text));
        addRenderableWidget(bind2Field);
        yOffset += 25;
        
        bind3Field = new EditBox(this.font, labelX, yOffset, fieldWidth, 20,
            Component.literal("Bind 3"));
        bind3Field.setMaxLength(256);
        bind3Field.setValue(Config.BIND_MESSAGE_3.get());
        bind3Field.setResponder((text) -> Config.BIND_MESSAGE_3.set(text));
        addRenderableWidget(bind3Field);
        yOffset += 25;
        
        bind4Field = new EditBox(this.font, labelX, yOffset, fieldWidth, 20,
            Component.literal("Bind 4"));
        bind4Field.setMaxLength(256);
        bind4Field.setValue(Config.BIND_MESSAGE_4.get());
        bind4Field.setResponder((text) -> Config.BIND_MESSAGE_4.set(text));
        addRenderableWidget(bind4Field);
        yOffset += 30;

        int hatBtnWidth = 90;
        int hatY = yOffset;
        Config.HatStyle currentHat = Config.HAT_STYLE.get();

        for (Config.HatStyle style : Config.HatStyle.values()) {
            int hatX = leftX + (style.ordinal() % 3) * (hatBtnWidth + 5);
            if (style.ordinal() % 3 == 0 && style.ordinal() > 0) {
                hatY += 25;
            }

            int finalHatY = hatY;
            addRenderableWidget(Button.builder(
                Component.literal(style.name() + (currentHat == style ? " ✓" : "")),
                (btn) -> {
                    Config.HAT_STYLE.set(style);
                    this.init(this.minecraft, this.width, this.height);
                })
                .bounds(hatX, finalHatY, hatBtnWidth, 20)
                .build());
        }
        
        yOffset = hatY + 35;
        
        // Show color sliders for current hat style
        if (currentHat != Config.HatStyle.NONE) {
            switch (currentHat) {
                case CROWN:
                    addSlider("Crown R1", Config.CROWN_R1.get(), 0, 255, leftX, (val) -> Config.CROWN_R1.set(val));
                    addSlider("Crown G1", Config.CROWN_G1.get(), 0, 255, leftX, (val) -> Config.CROWN_G1.set(val));
                    addSlider("Crown B1", Config.CROWN_B1.get(), 0, 255, leftX, (val) -> Config.CROWN_B1.set(val));
                    
                    yOffset -= 75;
                    
                    addSlider("Crown R2", Config.CROWN_R2.get(), 0, 255, rightX, (val) -> Config.CROWN_R2.set(val));
                    addSlider("Crown G2", Config.CROWN_G2.get(), 0, 255, rightX, (val) -> Config.CROWN_G2.set(val));
                    addSlider("Crown B2", Config.CROWN_B2.get(), 0, 255, rightX, (val) -> Config.CROWN_B2.set(val));
                    break;
                    
                case AURA:
                    addSlider("Aura R1", Config.AURA_R1.get(), 0, 255, leftX, (val) -> Config.AURA_R1.set(val));
                    addSlider("Aura G1", Config.AURA_G1.get(), 0, 255, leftX, (val) -> Config.AURA_G1.set(val));
                    addSlider("Aura B1", Config.AURA_B1.get(), 0, 255, leftX, (val) -> Config.AURA_B1.set(val));
                    
                    yOffset -= 75;
                    
                    addSlider("Aura R2", Config.AURA_R2.get(), 0, 255, rightX, (val) -> Config.AURA_R2.set(val));
                    addSlider("Aura G2", Config.AURA_G2.get(), 0, 255, rightX, (val) -> Config.AURA_G2.set(val));
                    addSlider("Aura B2", Config.AURA_B2.get(), 0, 255, rightX, (val) -> Config.AURA_B2.set(val));
                    break;
                    
                case WINGS:
                    addSlider("Wings R1", Config.WINGS_R1.get(), 0, 255, leftX, (val) -> Config.WINGS_R1.set(val));
                    addSlider("Wings G1", Config.WINGS_G1.get(), 0, 255, leftX, (val) -> Config.WINGS_G1.set(val));
                    addSlider("Wings B1", Config.WINGS_B1.get(), 0, 255, leftX, (val) -> Config.WINGS_B1.set(val));
                    
                    yOffset -= 75;
                    
                    addSlider("Wings R2", Config.WINGS_R2.get(), 0, 255, rightX, (val) -> Config.WINGS_R2.set(val));
                    addSlider("Wings G2", Config.WINGS_G2.get(), 0, 255, rightX, (val) -> Config.WINGS_G2.set(val));
                    addSlider("Wings B2", Config.WINGS_B2.get(), 0, 255, rightX, (val) -> Config.WINGS_B2.set(val));
                    break;
                    
                case HALO:
                    addSlider("Halo R1", Config.HALO_R1.get(), 0, 255, leftX, (val) -> Config.HALO_R1.set(val));
                    addSlider("Halo G1", Config.HALO_G1.get(), 0, 255, leftX, (val) -> Config.HALO_G1.set(val));
                    addSlider("Halo B1", Config.HALO_B1.get(), 0, 255, leftX, (val) -> Config.HALO_B1.set(val));
                    
                    yOffset -= 75;
                    
                    addSlider("Halo R2", Config.HALO_R2.get(), 0, 255, rightX, (val) -> Config.HALO_R2.set(val));
                    addSlider("Halo G2", Config.HALO_G2.get(), 0, 255, rightX, (val) -> Config.HALO_G2.set(val));
                    addSlider("Halo B2", Config.HALO_B2.get(), 0, 255, rightX, (val) -> Config.HALO_B2.set(val));
                    break;
            }
        }

        addRenderableWidget(Button.builder(
            Component.literal("Done"),
            (btn) -> this.minecraft.setScreen(this.parentScreen))
            .bounds(this.width / 2 - 100, this.height - 27, 200, 20)
            .build());
    }

    private void addSlider(String label, int value, int min, int max, int x, java.util.function.Consumer<Integer> onChange) {
        addRenderableWidget(new ForgeSlider(x, yOffset, 140, 20, 
            Component.literal(label + ": "), 
            Component.literal(""), 
            min, max, value, 1.0, 0, true) {
            @Override
            protected void applyValue() {
                onChange.accept((int)this.getValue());
                this.setMessage(Component.literal(label + ": " + (int)this.getValue()));
            }
        });
        yOffset += 25;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(graphics, mouseX, mouseY, partialTicks);
        super.render(graphics, mouseX, mouseY, partialTicks);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 10, 0xFFFFFF);
        
        int infoY = this.height - 50;
        graphics.drawCenteredString(this.font, 
            "Open GUI: " + KeyInputHandler.openGuiKey.saveString(), 
            this.width / 2, infoY, 0xAAAAAA);
        graphics.drawCenteredString(this.font, 
            "Binds: NumPad 1-4", 
            this.width / 2, infoY + 12, 0xAAAAAA);
    }

    @Override
    public void removed() {
        com.axmed555.visuals.AxmedVisuals.saveConfig();
        super.removed();
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(this.parentScreen);
    }
}
